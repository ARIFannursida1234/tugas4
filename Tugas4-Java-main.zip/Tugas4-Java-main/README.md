# Tugas4-Java

<b>Nama  : Rizky Adi Ryanto</b><br>
<b>Nim   : 1901013044</b><br>
<b>Kelas : PBO B</b><br>

# Demo
<img src="https://github.com/Rizky1408/Tugas4-Java/blob/main/Tugas4.1.png" width="500">
<img src="https://github.com/Rizky1408/Tugas4-Java/blob/main/Tugas4.2.png" width="500">


